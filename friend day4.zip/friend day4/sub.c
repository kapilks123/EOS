int sub(int a, int b)
{
    int sub=0;
    sub= a - b;
    return sub;
}