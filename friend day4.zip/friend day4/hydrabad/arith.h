int add(int ,int ,int);

//Take two integers (a,b) as input
// result = subtraction of a & b i.e a-b
int sub(int , int);
//swap
int swap(int ,int);